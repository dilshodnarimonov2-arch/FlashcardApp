# 📚 FlashCard Android Ilovasi

Kotlin + Firebase asosidagi flashcard yodlash ilovasi.

## 🚀 Sozlash bo'yicha qo'llanma

### 1-qadam: Firebase yaratish

1. [Firebase Console](https://console.firebase.google.com/) ga kiring
2. **"Add project"** ni bosing → loyiha nomini kiriting (masalan: "FlashCardApp")
3. Google Analytics ni yoqish shart emas → **"Create project"**

### 2-qadam: Android ilovasini Firebase ga ulash

1. Firebase Console da **"Android"** ikonkasini bosing
2. Package name: `com.flashcard.app`
3. **"Register app"** ni bosing
4. `google-services.json` faylini yuklab oling
5. Bu faylni loyihaning **`app/`** papkasiga joylashtiring

### 3-qadam: Firebase xizmatlarini yoqish

**Authentication:**
1. Firebase Console → **Authentication** → **Get started**
2. **Sign-in method** → **Email/Password** ni yoqing

**Firestore Database:**
1. Firebase Console → **Firestore Database** → **Create database**
2. **"Start in test mode"** ni tanlang → **Next** → **Enable**

### 4-qadam: Android Studio da ochish

1. Android Studio ni oching
2. **File → Open** → FlashCard papkasini tanlang
3. Gradle sync bo'lishini kuting
4. `google-services.json` faylini `app/` papkasiga qo'yganingizga ishonch hosil qiling
5. **Run** tugmasini bosing yoki emulyatorda ishga tushiring

---

## 📁 Loyiha tuzilmasi

```
app/src/main/
├── AndroidManifest.xml
├── java/com/flashcard/app/
│   ├── models/
│   │   ├── Flashcard.kt         ← Ma'lumot modeli
│   │   └── User.kt              ← Foydalanuvchi modeli
│   ├── repository/
│   │   ├── AuthRepository.kt    ← Login/Register logikasi
│   │   └── FlashcardRepository.kt ← Firestore CRUD
│   └── ui/
│       ├── login/
│       │   └── LoginActivity.kt
│       ├── register/
│       │   └── RegisterActivity.kt
│       ├── home/
│       │   ├── HomeActivity.kt
│       │   └── FlashcardAdapter.kt
│       └── flashcard/
│           ├── AddFlashcardActivity.kt
│           └── StudyActivity.kt
└── res/
    ├── layout/
    │   ├── activity_login.xml
    │   ├── activity_register.xml
    │   ├── activity_home.xml
    │   ├── activity_add_flashcard.xml
    │   ├── activity_study.xml
    │   └── item_flashcard.xml
    ├── drawable/
    │   └── progress_bar_drawable.xml
    ├── menu/
    │   └── menu_home.xml
    └── values/
        ├── colors.xml
        ├── strings.xml
        └── themes.xml
```

## ✨ Ilova imkoniyatlari

- 🔐 Email/Parol orqali ro'yxatdan o'tish va kirish
- ➕ Yangi flashcard qo'shish (savol + javob)
- ✏️ Kartalarni tahrirlash
- 🗑️ Kartalarni o'chirish
- 📖 O'rganish rejimi (kartani bosib javobni ko'rish)
- 🔀 Kartalar aralashtirilib beriladi
- 📊 O'rganish progressi ko'rsatiladi
- ☁️ Barcha ma'lumotlar Firebase da saqlanadi

## 🎨 Ranglar

| Rang | Kod |
|------|-----|
| Asosiy rang (binafsha) | #6C63FF |
| Ikkinchi rang (pushti) | #FF6584 |
| Fon | #F8F9FA |

## 🛠️ Texnologiyalar

- **Kotlin** — dasturlash tili
- **Firebase Auth** — autentifikatsiya
- **Firebase Firestore** — bulutli baza
- **Material Design** — UI komponentlar
- **RecyclerView** — kartalar ro'yxati
- **CardView** — karta dizayni
