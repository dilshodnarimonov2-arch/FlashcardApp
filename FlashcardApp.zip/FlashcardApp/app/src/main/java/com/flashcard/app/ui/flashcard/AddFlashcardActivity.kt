package com.flashcard.app.ui.flashcard

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.flashcard.app.R
import com.flashcard.app.models.Flashcard
import com.flashcard.app.repository.FlashcardRepository

class AddFlashcardActivity : AppCompatActivity() {

    private lateinit var etQuestion: EditText
    private lateinit var etAnswer: EditText
    private lateinit var btnSave: Button
    private lateinit var progressBar: ProgressBar

    private val repository = FlashcardRepository()
    private var editingCard: Flashcard? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_flashcard)

        etQuestion = findViewById(R.id.etQuestion)
        etAnswer = findViewById(R.id.etAnswer)
        btnSave = findViewById(R.id.btnSave)
        progressBar = findViewById(R.id.progressBar)

        // Tahrirlash rejimi
        val cardId = intent.getStringExtra("flashcard_id")
        if (cardId != null) {
            supportActionBar?.title = "Kartani tahrirlash"
            etQuestion.setText(intent.getStringExtra("flashcard_question"))
            etAnswer.setText(intent.getStringExtra("flashcard_answer"))
            editingCard = Flashcard(
                id = cardId,
                question = intent.getStringExtra("flashcard_question") ?: "",
                answer = intent.getStringExtra("flashcard_answer") ?: ""
            )
        } else {
            supportActionBar?.title = "Yangi karta qo'shish"
        }

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        btnSave.setOnClickListener {
            val question = etQuestion.text.toString().trim()
            val answer = etAnswer.text.toString().trim()

            if (question.isEmpty()) { etQuestion.error = "Savol kiriting"; return@setOnClickListener }
            if (answer.isEmpty()) { etAnswer.error = "Javob kiriting"; return@setOnClickListener }

            setLoading(true)

            val card = editingCard
            if (card != null) {
                repository.updateFlashcard(card.copy(question = question, answer = answer),
                    onSuccess = {
                        setLoading(false)
                        Toast.makeText(this, "Karta yangilandi! ✅", Toast.LENGTH_SHORT).show()
                        finish()
                    },
                    onError = {
                        setLoading(false)
                        Toast.makeText(this, "Xato: $it", Toast.LENGTH_SHORT).show()
                    }
                )
            } else {
                repository.addFlashcard(question, answer,
                    onSuccess = {
                        setLoading(false)
                        Toast.makeText(this, "Karta qo'shildi! ✅", Toast.LENGTH_SHORT).show()
                        finish()
                    },
                    onError = {
                        setLoading(false)
                        Toast.makeText(this, "Xato: $it", Toast.LENGTH_SHORT).show()
                    }
                )
            }
        }
    }

    private fun setLoading(isLoading: Boolean) {
        progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
        btnSave.isEnabled = !isLoading
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}
