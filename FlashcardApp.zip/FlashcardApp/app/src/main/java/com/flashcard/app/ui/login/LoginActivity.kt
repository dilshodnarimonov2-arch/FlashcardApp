package com.flashcard.app.ui.login

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.flashcard.app.R
import com.flashcard.app.repository.AuthRepository
import com.flashcard.app.ui.home.HomeActivity
import com.flashcard.app.ui.register.RegisterActivity

class LoginActivity : AppCompatActivity() {

    private lateinit var etEmail: EditText
    private lateinit var etPassword: EditText
    private lateinit var btnLogin: Button
    private lateinit var tvRegister: TextView
    private lateinit var progressBar: ProgressBar

    private val authRepository = AuthRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Agar foydalanuvchi allaqachon login qilgan bo'lsa
        if (authRepository.currentUser != null) {
            goToHome()
            return
        }

        setContentView(R.layout.activity_login)

        etEmail = findViewById(R.id.etEmail)
        etPassword = findViewById(R.id.etPassword)
        btnLogin = findViewById(R.id.btnLogin)
        tvRegister = findViewById(R.id.tvRegister)
        progressBar = findViewById(R.id.progressBar)

        btnLogin.setOnClickListener {
            val email = etEmail.text.toString().trim()
            val password = etPassword.text.toString().trim()

            if (email.isEmpty()) {
                etEmail.error = "Email kiriting"
                return@setOnClickListener
            }
            if (password.isEmpty()) {
                etPassword.error = "Parol kiriting"
                return@setOnClickListener
            }
            if (password.length < 6) {
                etPassword.error = "Parol kamida 6 ta belgi bo'lishi kerak"
                return@setOnClickListener
            }

            setLoading(true)

            authRepository.login(email, password,
                onSuccess = {
                    setLoading(false)
                    goToHome()
                },
                onError = { error ->
                    setLoading(false)
                    Toast.makeText(this, "Xato: $error", Toast.LENGTH_LONG).show()
                }
            )
        }

        tvRegister.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
    }

    private fun setLoading(isLoading: Boolean) {
        progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
        btnLogin.isEnabled = !isLoading
    }

    private fun goToHome() {
        startActivity(Intent(this, HomeActivity::class.java))
        finish()
    }
}
