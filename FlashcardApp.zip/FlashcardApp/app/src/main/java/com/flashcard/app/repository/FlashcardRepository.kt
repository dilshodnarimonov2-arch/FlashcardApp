package com.flashcard.app.repository

import com.flashcard.app.models.Flashcard
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query

class FlashcardRepository {

    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()
    private val userId get() = auth.currentUser?.uid ?: ""

    fun getFlashcards(onResult: (List<Flashcard>) -> Unit, onError: (String) -> Unit) {
        db.collection("flashcards")
            .whereEqualTo("userId", userId)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .get()
            .addOnSuccessListener { result ->
                val list = result.map { it.toObject(Flashcard::class.java) }
                onResult(list)
            }
            .addOnFailureListener {
                onError(it.message ?: "Xato yuz berdi")
            }
    }

    fun addFlashcard(question: String, answer: String, onSuccess: () -> Unit, onError: (String) -> Unit) {
        val docRef = db.collection("flashcards").document()
        val card = Flashcard(
            id = docRef.id,
            question = question,
            answer = answer,
            userId = userId
        )
        docRef.set(card)
            .addOnSuccessListener { onSuccess() }
            .addOnFailureListener { onError(it.message ?: "Xato yuz berdi") }
    }

    fun updateFlashcard(flashcard: Flashcard, onSuccess: () -> Unit, onError: (String) -> Unit) {
        db.collection("flashcards").document(flashcard.id)
            .set(flashcard)
            .addOnSuccessListener { onSuccess() }
            .addOnFailureListener { onError(it.message ?: "Xato yuz berdi") }
    }

    fun deleteFlashcard(id: String, onSuccess: () -> Unit, onError: (String) -> Unit) {
        db.collection("flashcards").document(id)
            .delete()
            .addOnSuccessListener { onSuccess() }
            .addOnFailureListener { onError(it.message ?: "Xato yuz berdi") }
    }
}
