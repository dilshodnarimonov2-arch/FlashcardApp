package com.flashcard.app.models

data class Flashcard(
    val id: String = "",
    val question: String = "",
    val answer: String = "",
    val userId: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
