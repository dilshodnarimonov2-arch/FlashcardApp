package com.flashcard.app.ui.home

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.flashcard.app.R
import com.flashcard.app.models.Flashcard
import com.flashcard.app.repository.AuthRepository
import com.flashcard.app.repository.FlashcardRepository
import com.flashcard.app.ui.flashcard.AddFlashcardActivity
import com.flashcard.app.ui.flashcard.StudyActivity
import com.flashcard.app.ui.login.LoginActivity
import com.google.android.material.floatingactionbutton.FloatingActionButton

class HomeActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var tvEmpty: TextView
    private lateinit var fabAdd: FloatingActionButton
    private lateinit var btnStudy: com.google.android.material.button.MaterialButton

    private val flashcardRepository = FlashcardRepository()
    private val authRepository = AuthRepository()
    private lateinit var adapter: FlashcardAdapter
    private val flashcards = mutableListOf<Flashcard>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        recyclerView = findViewById(R.id.recyclerView)
        progressBar = findViewById(R.id.progressBar)
        tvEmpty = findViewById(R.id.tvEmpty)
        fabAdd = findViewById(R.id.fabAdd)
        btnStudy = findViewById(R.id.btnStudy)

        adapter = FlashcardAdapter(flashcards,
            onDelete = { card -> confirmDelete(card) },
            onEdit = { card ->
                val intent = Intent(this, AddFlashcardActivity::class.java)
                intent.putExtra("flashcard_id", card.id)
                intent.putExtra("flashcard_question", card.question)
                intent.putExtra("flashcard_answer", card.answer)
                startActivity(intent)
            }
        )

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        fabAdd.setOnClickListener {
            startActivity(Intent(this, AddFlashcardActivity::class.java))
        }

        btnStudy.setOnClickListener {
            if (flashcards.isEmpty()) {
                Toast.makeText(this, "Avval kartalar qo'shing!", Toast.LENGTH_SHORT).show()
            } else {
                startActivity(Intent(this, StudyActivity::class.java))
            }
        }
    }

    override fun onResume() {
        super.onResume()
        loadFlashcards()
    }

    private fun loadFlashcards() {
        progressBar.visibility = View.VISIBLE
        flashcardRepository.getFlashcards(
            onResult = { list ->
                progressBar.visibility = View.GONE
                flashcards.clear()
                flashcards.addAll(list)
                adapter.notifyDataSetChanged()
                tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
                btnStudy.isEnabled = list.isNotEmpty()
            },
            onError = { error ->
                progressBar.visibility = View.GONE
                Toast.makeText(this, "Xato: $error", Toast.LENGTH_SHORT).show()
            }
        )
    }

    private fun confirmDelete(card: Flashcard) {
        AlertDialog.Builder(this)
            .setTitle("O'chirish")
            .setMessage("Bu kartani o'chirishni xohlaysizmi?")
            .setPositiveButton("Ha") { _, _ ->
                flashcardRepository.deleteFlashcard(card.id,
                    onSuccess = { loadFlashcards() },
                    onError = { Toast.makeText(this, "Xato: $it", Toast.LENGTH_SHORT).show() }
                )
            }
            .setNegativeButton("Bekor qilish", null)
            .show()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_home, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.action_logout) {
            authRepository.logout()
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}
