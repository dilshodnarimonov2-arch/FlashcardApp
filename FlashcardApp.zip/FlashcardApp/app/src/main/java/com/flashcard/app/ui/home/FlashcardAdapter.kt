package com.flashcard.app.ui.home

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.flashcard.app.R
import com.flashcard.app.models.Flashcard

class FlashcardAdapter(
    private val items: List<Flashcard>,
    private val onDelete: (Flashcard) -> Unit,
    private val onEdit: (Flashcard) -> Unit
) : RecyclerView.Adapter<FlashcardAdapter.ViewHolder>() {

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvQuestion: TextView = view.findViewById(R.id.tvQuestion)
        val tvAnswer: TextView = view.findViewById(R.id.tvAnswer)
        val btnDelete: ImageButton = view.findViewById(R.id.btnDelete)
        val btnEdit: ImageButton = view.findViewById(R.id.btnEdit)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_flashcard, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val card = items[position]
        holder.tvQuestion.text = card.question
        holder.tvAnswer.text = card.answer
        holder.btnDelete.setOnClickListener { onDelete(card) }
        holder.btnEdit.setOnClickListener { onEdit(card) }
    }

    override fun getItemCount() = items.size
}
