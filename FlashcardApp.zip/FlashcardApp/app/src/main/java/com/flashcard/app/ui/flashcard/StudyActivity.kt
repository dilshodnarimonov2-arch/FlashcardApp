package com.flashcard.app.ui.flashcard

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import com.flashcard.app.R
import com.flashcard.app.repository.FlashcardRepository

class StudyActivity : AppCompatActivity() {

    private lateinit var tvProgress: TextView
    private lateinit var tvHint: TextView
    private lateinit var tvContent: TextView
    private lateinit var cardView: CardView
    private lateinit var btnNext: Button
    private lateinit var btnPrev: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var progressBarStudy: ProgressBar

    private val repository = FlashcardRepository()
    private val flashcards = mutableListOf<com.flashcard.app.models.Flashcard>()
    private var currentIndex = 0
    private var isShowingAnswer = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_study)

        tvProgress = findViewById(R.id.tvProgress)
        tvHint = findViewById(R.id.tvHint)
        tvContent = findViewById(R.id.tvContent)
        cardView = findViewById(R.id.cardView)
        btnNext = findViewById(R.id.btnNext)
        btnPrev = findViewById(R.id.btnPrev)
        progressBar = findViewById(R.id.progressBar)
        progressBarStudy = findViewById(R.id.progressBarStudy)

        supportActionBar?.title = "O'rganish"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        cardView.setOnClickListener {
            isShowingAnswer = !isShowingAnswer
            updateCard()
        }

        btnNext.setOnClickListener {
            if (currentIndex < flashcards.size - 1) {
                currentIndex++
                isShowingAnswer = false
                updateCard()
            } else {
                Toast.makeText(this, "🎉 Barcha kartalar ko'rib chiqildi!", Toast.LENGTH_LONG).show()
            }
        }

        btnPrev.setOnClickListener {
            if (currentIndex > 0) {
                currentIndex--
                isShowingAnswer = false
                updateCard()
            }
        }

        loadCards()
    }

    private fun loadCards() {
        progressBar.visibility = View.VISIBLE
        repository.getFlashcards(
            onResult = { list ->
                progressBar.visibility = View.GONE
                flashcards.addAll(list.shuffled())
                if (flashcards.isNotEmpty()) {
                    progressBarStudy.max = flashcards.size
                    updateCard()
                }
            },
            onError = { error ->
                progressBar.visibility = View.GONE
                Toast.makeText(this, "Xato: $error", Toast.LENGTH_SHORT).show()
            }
        )
    }

    private fun updateCard() {
        if (flashcards.isEmpty()) return
        val card = flashcards[currentIndex]

        tvProgress.text = "${currentIndex + 1} / ${flashcards.size}"
        progressBarStudy.progress = currentIndex + 1

        if (isShowingAnswer) {
            tvHint.text = "Javob:"
            tvContent.text = card.answer
            cardView.setCardBackgroundColor(getColor(R.color.card_answer_bg))
        } else {
            tvHint.text = "Savol: (Javobni ko'rish uchun kartani bosing)"
            tvContent.text = card.question
            cardView.setCardBackgroundColor(getColor(R.color.card_question_bg))
        }

        btnPrev.isEnabled = currentIndex > 0
        btnNext.text = if (currentIndex == flashcards.size - 1) "Tugadi ✅" else "Keyingi →"
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}
