package com.flashcard.app.ui.register

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.flashcard.app.R
import com.flashcard.app.repository.AuthRepository
import com.flashcard.app.ui.home.HomeActivity

class RegisterActivity : AppCompatActivity() {

    private lateinit var etEmail: EditText
    private lateinit var etPassword: EditText
    private lateinit var etConfirmPassword: EditText
    private lateinit var btnRegister: Button
    private lateinit var tvLogin: TextView
    private lateinit var progressBar: ProgressBar

    private val authRepository = AuthRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        etEmail = findViewById(R.id.etEmail)
        etPassword = findViewById(R.id.etPassword)
        etConfirmPassword = findViewById(R.id.etConfirmPassword)
        btnRegister = findViewById(R.id.btnRegister)
        tvLogin = findViewById(R.id.tvLogin)
        progressBar = findViewById(R.id.progressBar)

        btnRegister.setOnClickListener {
            val email = etEmail.text.toString().trim()
            val password = etPassword.text.toString().trim()
            val confirmPassword = etConfirmPassword.text.toString().trim()

            if (email.isEmpty()) { etEmail.error = "Email kiriting"; return@setOnClickListener }
            if (password.isEmpty()) { etPassword.error = "Parol kiriting"; return@setOnClickListener }
            if (password.length < 6) { etPassword.error = "Kamida 6 ta belgi"; return@setOnClickListener }
            if (password != confirmPassword) { etConfirmPassword.error = "Parollar mos emas"; return@setOnClickListener }

            setLoading(true)

            authRepository.register(email, password,
                onSuccess = {
                    setLoading(false)
                    Toast.makeText(this, "Muvaffaqiyatli ro'yxatdan o'tdingiz!", Toast.LENGTH_SHORT).show()
                    startActivity(Intent(this, HomeActivity::class.java))
                    finish()
                },
                onError = { error ->
                    setLoading(false)
                    Toast.makeText(this, "Xato: $error", Toast.LENGTH_LONG).show()
                }
            )
        }

        tvLogin.setOnClickListener { finish() }
    }

    private fun setLoading(isLoading: Boolean) {
        progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
        btnRegister.isEnabled = !isLoading
    }
}
